import { useState, useEffect } from 'react';
import { Calculator, ArrowRightLeft, Ruler, Building2, Home, Euro, RotateCcw, Save, Download, Trash2, History } from 'lucide-react';

interface SavedCalculation {
  id: string;
  name: string;
  calculator: string;
  result: string;
  date: string;
}

const calculators = [
  { id: 'honorarios', name: 'Honorários ICHPOP', description: 'Tabela oficial de honorários', icon: Euro },
  { id: 'areas', name: 'Conversor de Áreas', description: 'm², ft², ha, acres', icon: ArrowRightLeft },
  { id: 'custo', name: 'Custo de Construção', description: 'Estimativa por m²', icon: Building2 },
  { id: 'imovel', name: 'Avaliação Imobiliária', description: 'Valor de mercado', icon: Home },
];

const constructionRates: Record<string, number> = {
  economica: 700,
  media: 1000,
  alta: 1500,
  luxo: 2200,
};

const locationRates: Record<string, { rate: number; region: string }> = {
  lisboa: { rate: 4500, region: 'Lisboa' },
  porto: { rate: 3800, region: 'Porto' },
  algarve: { rate: 4200, region: 'Algarve' },
  coimbra: { rate: 2800, region: 'Coimbra' },
  braga: { rate: 2600, region: 'Braga' },
  interior: { rate: 1800, region: 'Interior' },
};

const typeMultipliers: Record<string, number> = {
  apartamento: 1,
  moradia: 1.15,
  loja: 1.3,
  escritorio: 1.25,
};

const ichpopRates = [
  { max: 50, rate: 40 },
  { max: 100, rate: 35 },
  { max: 250, rate: 30 },
  { max: 500, rate: 25 },
  { max: 1000, rate: 22 },
  { max: 2500, rate: 18 },
  { max: 5000, rate: 15 },
  { max: 10000, rate: 12 },
  { max: Infinity, rate: 10 },
];

export default function CalculatorPage() {
  const [activeCalculator, setActiveCalculator] = useState<string | null>(null);
  const [savedCalculations, setSavedCalculations] = useState<SavedCalculation[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Honorários
  const [honArea, setHonArea] = useState('');
  const [honType, setHonType] = useState('habitacao');
  const [honComplexity, setHonComplexity] = useState('normal');

  // Áreas
  const [areaValue, setAreaValue] = useState('');
  const [fromUnit, setFromUnit] = useState('m2');
  const [toUnit, setToUnit] = useState('ft2');

  // Custo
  const [custoArea, setCustoArea] = useState('');
  const [custoTipo, setCustoTipo] = useState('media');

  // Imóvel
  const [imovelArea, setImovelArea] = useState('');
  const [imovelLocal, setImovelLocal] = useState('lisboa');
  const [imovelTipo, setImovelTipo] = useState('apartamento');
  const [imovelAno, setImovelAno] = useState('2020');
  const [imovelEstado, setImovelEstado] = useState('bom');

  useEffect(() => {
    const saved = localStorage.getItem('fa360-calculations');
    if (saved) {
      setSavedCalculations(JSON.parse(saved));
    }
  }, []);

  const saveCalculation = (name: string, result: string) => {
    const newCalc: SavedCalculation = {
      id: Date.now().toString(),
      name,
      calculator: activeCalculator || '',
      result,
      date: new Date().toLocaleDateString('pt-PT'),
    };
    const updated = [...savedCalculations, newCalc];
    setSavedCalculations(updated);
    localStorage.setItem('fa360-calculations', JSON.stringify(updated));
  };

  const deleteSaved = (id: string) => {
    const updated = savedCalculations.filter(c => c.id !== id);
    setSavedCalculations(updated);
    localStorage.setItem('fa360-calculations', JSON.stringify(updated));
  };

  const calculateHonorarios = () => {
    const area = parseFloat(honArea) || 0;
    const rateBase = ichpopRates.find(r => area <= r.max)?.rate || 10;
    const typeMult = honType === 'comercio' ? 1.3 : honType === 'industria' ? 1.2 : 1;
    const compMult = honComplexity === 'alta' ? 1.4 : honComplexity === 'baixa' ? 0.85 : 1;
    return area * rateBase * typeMult * compMult;
  };

  const convertArea = () => {
    const value = parseFloat(areaValue) || 0;
    const conversions: Record<string, Record<string, number>> = {
      m2: { m2: 1, ft2: 10.7639, ha: 0.0001, ac: 0.000247 },
      ft2: { m2: 0.092903, ft2: 1, ha: 0.00000929, ac: 0.00002296 },
      ha: { m2: 10000, ft2: 107639, ha: 1, ac: 2.47105 },
      ac: { m2: 4046.86, ft2: 43560, ha: 0.404686, ac: 1 },
    };
    return value * (conversions[fromUnit]?.[toUnit] || 1);
  };

  const calculateCusto = () => {
    const area = parseFloat(custoArea) || 0;
    const rate = constructionRates[custoTipo] || 1000;
    return area * rate;
  };

  const calculateImovel = () => {
    const area = parseFloat(imovelArea) || 0;
    const baseRate = locationRates[imovelLocal]?.rate || 3000;
    const typeMult = typeMultipliers[imovelTipo] || 1;
    const idade = new Date().getFullYear() - parseInt(imovelAno);
    const depreciacao = Math.max(0.5, 1 - idade * 0.015);
    const estadoMult = imovelEstado === 'excelente' ? 1.1 : imovelEstado === 'bom' ? 1 : imovelEstado === 'regular' ? 0.9 : 0.75;
    return area * baseRate * typeMult * depreciacao * estadoMult;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR' }).format(value);
  };

  const resetCalculator = () => {
    setActiveCalculator(null);
    setHonArea('');
    setAreaValue('');
    setCustoArea('');
    setImovelArea('');
  };

  const exportResults = () => {
    const data = { savedCalculations, exportDate: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fa360-calculos-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-muted-foreground mb-1">
            <Calculator className="w-4 h-4" />
            <span className="text-sm">Ferramentas de Cálculo</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold">Calculadoras</h1>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowHistory(!showHistory)} className="flex items-center gap-2 px-4 py-2.5 bg-muted border border-border rounded-lg hover:bg-muted/80 transition-colors">
            <History className="w-4 h-4" />
            <span>Histórico</span>
            {savedCalculations.length > 0 && <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs rounded-full">{savedCalculations.length}</span>}
          </button>
          {activeCalculator && (
            <button onClick={resetCalculator} className="flex items-center gap-2 px-4 py-2.5 bg-muted border border-border rounded-lg hover:bg-muted/80 transition-colors">
              <RotateCcw className="w-4 h-4" />
              <span>Limpar</span>
            </button>
          )}
        </div>
      </div>

      {/* History Panel */}
      {showHistory && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h3 className="font-semibold flex items-center gap-2"><Save className="w-4 h-4" />Cálculos Guardados</h3>
            {savedCalculations.length > 0 && (
              <button onClick={exportResults} className="flex items-center gap-2 px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                <Download className="w-4 h-4" />Exportar
              </button>
            )}
          </div>
          <div className="p-4">
            {savedCalculations.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">Nenhum cálculo guardado</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {savedCalculations.map((calc) => (
                  <div key={calc.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium">{calc.name}</p>
                      <p className="text-sm text-muted-foreground">{calc.calculator} • {calc.date}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-semibold text-primary">{calc.result}</span>
                      <button onClick={() => deleteSaved(calc.id)} className="p-1.5 hover:bg-destructive/10 text-destructive rounded transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Calculator Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {calculators.map((calc) => (
          <button key={calc.id} onClick={() => setActiveCalculator(calc.id)} className={`p-5 bg-card border rounded-xl text-left transition-all group ${activeCalculator === calc.id ? 'border-primary ring-2 ring-primary/20' : 'border-border hover:border-muted-foreground/30'}`}>
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <calc.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-1">{calc.name}</h3>
            <p className="text-sm text-muted-foreground">{calc.description}</p>
          </button>
        ))}
      </div>

      {/* Honorários Form */}
      {activeCalculator === 'honorarios' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/50 flex items-center gap-3">
            <Euro className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Honorários ICHPOP</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2">Área (m²)</label>
                <input type="number" min="0" value={honArea} onChange={(e) => setHonArea(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none" placeholder="Ex: 150" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Tipo</label>
                <select value={honType} onChange={(e) => setHonType(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="habitacao">Habitação</option>
                  <option value="comercio">Comércio</option>
                  <option value="industria">Indústria</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Complexidade</label>
                <select value={honComplexity} onChange={(e) => setHonComplexity(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="baixa">Baixa (x0.85)</option>
                  <option value="normal">Normal (x1.0)</option>
                  <option value="alta">Alta (x1.4)</option>
                </select>
              </div>
            </div>
            <div className="p-6 bg-primary/5 border border-primary/20 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Honorários Estimados</span>
                {honArea && <button onClick={() => saveCalculation(`Honorários - ${honArea}m²`, formatCurrency(calculateHonorarios()))} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors"><Save className="w-4 h-4" /><span>Guardar</span></button>}
              </div>
              <p className="text-4xl font-bold text-primary">{honArea ? formatCurrency(calculateHonorarios()) : '---'}</p>
              <p className="text-xs text-muted-foreground mt-3">* Baseado na tabela ICHPOP. Valor sem IVA.</p>
            </div>
          </div>
        </div>
      )}

      {/* Áreas Form */}
      {activeCalculator === 'areas' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/50 flex items-center gap-3">
            <ArrowRightLeft className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Conversor de Áreas</h3>
          </div>
          <div className="p-6">
            <div className="flex flex-col sm:flex-row items-end gap-4 mb-6">
              <div className="flex-1 w-full">
                <label className="block text-sm font-medium mb-2">Valor</label>
                <input type="number" min="0" step="any" value={areaValue} onChange={(e) => setAreaValue(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none" placeholder="Ex: 100" />
              </div>
              <div className="w-full sm:w-40">
                <label className="block text-sm font-medium mb-2">De</label>
                <select value={fromUnit} onChange={(e) => setFromUnit(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="m2">m²</option>
                  <option value="ft2">ft²</option>
                  <option value="ha">ha</option>
                  <option value="ac">acres</option>
                </select>
              </div>
              <div className="flex items-center justify-center pb-3">
                <ArrowRightLeft className="w-5 h-5 text-muted-foreground" />
              </div>
              <div className="w-full sm:w-40">
                <label className="block text-sm font-medium mb-2">Para</label>
                <select value={toUnit} onChange={(e) => setToUnit(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="m2">m²</option>
                  <option value="ft2">ft²</option>
                  <option value="ha">ha</option>
                  <option value="ac">acres</option>
                </select>
              </div>
            </div>
            <div className="p-6 bg-primary/5 border border-primary/20 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Resultado</span>
                {areaValue && <button onClick={() => saveCalculation(`${areaValue} ${fromUnit} → ${toUnit}`, `${convertArea().toLocaleString('pt-PT', { maximumFractionDigits: 6 })} ${toUnit}`)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors"><Save className="w-4 h-4" /><span>Guardar</span></button>}
              </div>
              <p className="text-4xl font-bold text-primary">{areaValue ? `${convertArea().toLocaleString('pt-PT', { maximumFractionDigits: 6 })} ${toUnit}` : '---'}</p>
            </div>
          </div>
        </div>
      )}

      {/* Custo Form */}
      {activeCalculator === 'custo' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/50 flex items-center gap-3">
            <Building2 className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Custo de Construção</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2">Área (m²)</label>
                <input type="number" min="0" value={custoArea} onChange={(e) => setCustoArea(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none" placeholder="Ex: 200" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Qualidade</label>
                <select value={custoTipo} onChange={(e) => setCustoTipo(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="economica">Económica (700€/m²)</option>
                  <option value="media">Média (1.000€/m²)</option>
                  <option value="alta">Alta (1.500€/m²)</option>
                  <option value="luxo">Luxo (2.200€/m²)</option>
                </select>
              </div>
            </div>
            <div className="p-6 bg-primary/5 border border-primary/20 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Custo Estimado</span>
                {custoArea && <button onClick={() => saveCalculation(`Construção - ${custoArea}m² ${custoTipo}`, formatCurrency(calculateCusto()))} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors"><Save className="w-4 h-4" /><span>Guardar</span></button>}
              </div>
              <p className="text-4xl font-bold text-primary">{custoArea ? formatCurrency(calculateCusto()) : '---'}</p>
              <p className="text-xs text-muted-foreground mt-3">* Valor aproximado. Inclui mão-de-obra e materiais.</p>
            </div>
          </div>
        </div>
      )}

      {/* Imóvel Form */}
      {activeCalculator === 'imovel' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/50 flex items-center gap-3">
            <Home className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Avaliação Imobiliária</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2">Área (m²)</label>
                <input type="number" min="0" value={imovelArea} onChange={(e) => setImovelArea(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none" placeholder="Ex: 120" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Localização</label>
                <select value={imovelLocal} onChange={(e) => setImovelLocal(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  {Object.entries(locationRates).map(([key, { rate, region }]) => (
                    <option key={key} value={key}>{region} ({rate}€/m²)</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Tipo</label>
                <select value={imovelTipo} onChange={(e) => setImovelTipo(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="apartamento">Apartamento (x1.0)</option>
                  <option value="moradia">Moradia (x1.15)</option>
                  <option value="loja">Loja (x1.3)</option>
                  <option value="escritorio">Escritório (x1.25)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Ano Construção</label>
                <input type="number" min="1900" max={new Date().getFullYear()} value={imovelAno} onChange={(e) => setImovelAno(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Estado</label>
                <select value={imovelEstado} onChange={(e) => setImovelEstado(e.target.value)} className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:border-primary focus:outline-none">
                  <option value="excelente">Excelente (x1.1)</option>
                  <option value="bom">Bom (x1.0)</option>
                  <option value="regular">Regular (x0.9)</option>
                  <option value="mau">Necessita obras (x0.75)</option>
                </select>
              </div>
            </div>
            <div className="p-6 bg-primary/5 border border-primary/20 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Valor Estimado</span>
                {imovelArea && <button onClick={() => saveCalculation(`Imóvel - ${imovelArea}m² ${locationRates[imovelLocal]?.region}`, formatCurrency(calculateImovel()))} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm hover:bg-primary/90 transition-colors"><Save className="w-4 h-4" /><span>Guardar</span></button>}
              </div>
              <p className="text-4xl font-bold text-primary">{imovelArea ? formatCurrency(calculateImovel()) : '---'}</p>
              <p className="text-xs text-muted-foreground mt-3">* Valor de mercado estimado. Consulte um avaliador credenciado.</p>
            </div>
          </div>
        </div>
      )}

      {!activeCalculator && (
        <div className="text-center py-16 text-muted-foreground">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
            <Calculator className="w-10 h-10 opacity-50" />
          </div>
          <p className="text-lg">Selecione uma calculadora para começar</p>
          <p className="text-sm mt-2">4 ferramentas disponíveis</p>
        </div>
      )}
    </div>
  );
}
