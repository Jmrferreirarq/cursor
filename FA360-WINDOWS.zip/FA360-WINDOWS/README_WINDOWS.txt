==========================================
   FA-360 - Instrucoes Windows
==========================================

REPOSITORIO: https://github.com/Jmrferreirarq/Kimi.git

PASSOS PARA INSTALAR E ENVIAR:

1. Extrai o ficheiro FA360-COMPLETO.zip
   (Deves ter uma pasta 'app' com o codigo)

2. Abre a pasta 'app' no Explorador de Ficheiros

3. Copia estes 2 ficheiros para DENTRO da pasta 'app':
   - INSTALAR.bat
   - PUSH.bat

4. Duplo clique em INSTALAR.bat
   (Isto configura o Git e prepara o repositorio)

5. Duplo clique em PUSH.bat
   (Isto envia o codigo para o GitHub)

==========================================

SOLUCAO DE PROBLEMAS:

- Se der erro "git nao reconhecido":
  Instala o Git: https://git-scm.com/download/win

- Se der erro de login no GitHub:
  O Git vai pedir username e password/token
  Usa o teu token de acesso pessoal do GitHub

- Se a pasta estiver errada:
  Certifica-te que os .bat estao na mesma pasta
  que o ficheiro package.json

==========================================
