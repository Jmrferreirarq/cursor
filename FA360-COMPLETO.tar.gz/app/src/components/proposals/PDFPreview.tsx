import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  X, Download, FileText, Calendar, User, MapPin, Euro, CheckCircle, 
  Mail, Phone, Building2, Hash, Share2, Printer, Eye, Send
} from 'lucide-react';
import { toast } from 'sonner';

interface ProposalPhase {
  id: string;
  name: string;
  description: string;
  value: number;
  selected: boolean;
}

interface ClientData {
  name: string;
  email: string;
  phone: string;
  address: string;
  municipality: string;
  nif?: string;
}

interface PDFPreviewProps {
  isOpen: boolean;
  onClose: () => void;
  clientData: ClientData;
  projectType: string;
  projectTypeLabel: string;
  phases: ProposalPhase[];
  subtotal: number;
  vatRate: number;
  vatAmount: number;
  total: number;
  proposalNumber: string;
  proposalDate: string;
  validUntil: string;
}

export default function PDFPreview({
  isOpen,
  onClose,
  clientData,
  projectType,
  projectTypeLabel,
  phases,
  subtotal,
  vatRate,
  vatAmount,
  total,
  proposalNumber,
  proposalDate,
  validUntil,
}: PDFPreviewProps) {
  const [zoom, setZoom] = useState(100);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailMessage, setEmailMessage] = useState('');
  const pdfRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-PT', {
      style: 'currency',
      currency: 'EUR',
    }).format(value);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '--/--/----';
    return new Date(dateStr).toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  };

  const formatShortDate = (dateStr: string) => {
    if (!dateStr) return '--/--/----';
    return new Date(dateStr).toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Proposta ${proposalNumber}`,
          text: `Proposta de ${projectTypeLabel} - ${formatCurrency(total)}`,
        });
      } catch {
        toast.info('Partilha cancelada');
      }
    } else {
      toast.info('Partilha não suportada neste navegador');
    }
  };

  const handleSendEmail = () => {
    if (!clientData.email) {
      toast.error('Cliente não tem email definido');
      return;
    }
    setShowEmailModal(true);
  };

  const sendEmail = () => {
    const subject = encodeURIComponent(`Proposta ${proposalNumber} - Ferreira Arquitetos`);
    const body = encodeURIComponent(
      `Exmo(a). Sr(a). ${clientData.name},\n\n` +
      `Envio em anexo a nossa proposta para ${projectTypeLabel}.\n\n` +
      `${emailMessage}\n\n` +
      `Valor total: ${formatCurrency(total)}\n` +
      `Válida até: ${formatDate(validUntil)}\n\n` +
      `Aguardamos o seu contacto.\n\n` +
      `Atenciosamente,\n` +
      `Ferreira Arquitetos`
    );
    window.open(`mailto:${clientData.email}?subject=${subject}&body=${body}`);
    setShowEmailModal(false);
    toast.success('Email preparado');
  };

  const handleDownloadPDF = () => {
    toast.info('Geração de PDF em desenvolvimento. Use Imprimir > Guardar como PDF.');
    handlePrint();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="relative w-full max-w-5xl h-[90vh] bg-background rounded-2xl shadow-2xl overflow-hidden flex flex-col"
      >
        {/* Toolbar */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-card">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              <span className="font-medium">Pré-visualização</span>
            </div>
            <span className="text-sm text-muted-foreground px-2 py-1 bg-muted rounded">{proposalNumber}</span>
            <div className="flex items-center gap-1 ml-4">
              <button 
                onClick={() => setZoom(Math.max(50, zoom - 10))}
                className="p-1.5 hover:bg-muted rounded transition-colors"
              >
                -
              </button>
              <span className="text-sm w-12 text-center">{zoom}%</span>
              <button 
                onClick={() => setZoom(Math.min(150, zoom + 10))}
                className="p-1.5 hover:bg-muted rounded transition-colors"
              >
                +
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-muted hover:bg-muted/80 rounded-lg transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">Partilhar</span>
            </button>
            <button
              onClick={handleSendEmail}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-muted hover:bg-muted/80 rounded-lg transition-colors"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Enviar</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-muted hover:bg-muted/80 rounded-lg transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">Imprimir</span>
            </button>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PDF Content */}
        <div className="flex-1 overflow-auto bg-muted/50 p-8">
          <div 
            ref={pdfRef}
            className="mx-auto bg-white shadow-xl"
            style={{ 
              width: '210mm', 
              minHeight: '297mm',
              transform: `scale(${zoom / 100})`,
              transformOrigin: 'top center',
            }}
          >
            {/* Header */}
            <div className="p-10 border-b-4 border-primary bg-gradient-to-r from-primary/5 to-transparent">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-baseline gap-1">
                    <h1 className="text-4xl font-black text-gray-900 tracking-tight">FERREIRA</h1>
                    <span className="text-primary text-xl">®</span>
                  </div>
                  <p className="text-xl text-gray-600 font-light tracking-widest">ARQUITETOS</p>
                  <div className="flex items-center gap-2 mt-3 text-sm text-gray-500">
                    <Building2 className="w-4 h-4" />
                    <span>Arquitetura • Design • Construção</span>
                  </div>
                  <div className="mt-2 text-xs text-gray-400">
                    <p>NIF: 123456789 | geral@fa360.pt | +351 220 000 000</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="inline-block px-4 py-2 bg-primary text-white rounded-lg">
                    <p className="text-xs uppercase tracking-wider">Proposta Comercial</p>
                    <p className="text-2xl font-bold">{proposalNumber}</p>
                  </div>
                  <div className="mt-4 space-y-1 text-sm text-gray-600">
                    <div className="flex items-center gap-2 justify-end">
                      <Calendar className="w-4 h-4" />
                      <span>Data: <strong>{formatShortDate(proposalDate)}</strong></span>
                    </div>
                    <div className="flex items-center gap-2 justify-end text-primary">
                      <span>Válida até: <strong>{formatShortDate(validUntil)}</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Client Info */}
            <div className="p-10 border-b border-gray-200">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <User className="w-4 h-4" />
                Dados do Cliente
              </h2>
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{clientData.name || 'Nome do Cliente'}</p>
                      {clientData.nif && <p className="text-xs text-gray-500">NIF: {clientData.nif}</p>}
                    </div>
                  </div>
                  {clientData.email && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{clientData.email}</span>
                    </div>
                  )}
                  {clientData.phone && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{clientData.phone}</span>
                    </div>
                  )}
                </div>
                <div>
                  {(clientData.address || clientData.municipality) && (
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-gray-500" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Localização do Projeto</p>
                        <p className="text-gray-600">{clientData.address}</p>
                        {clientData.municipality && (
                          <p className="text-gray-600">{clientData.municipality}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Project Info */}
            <div className="p-10 border-b border-gray-200">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Tipo de Projeto
              </h2>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                  <CheckCircle className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{projectTypeLabel}</p>
                  <p className="text-sm text-gray-500">Projeto de arquitetura completo</p>
                </div>
              </div>
            </div>

            {/* Phases Table */}
            <div className="p-10">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-6 flex items-center gap-2">
                <Hash className="w-4 h-4" />
                Fases e Serviços Incluídos
              </h2>
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left py-3 text-sm font-semibold text-gray-700">Fase</th>
                    <th className="text-left py-3 text-sm font-semibold text-gray-700">Descrição do Serviço</th>
                    <th className="text-right py-3 text-sm font-semibold text-gray-700">Valor</th>
                  </tr>
                </thead>
                <tbody>
                  {phases.map((phase, index) => (
                    <tr key={phase.id} className={`border-b border-gray-100 ${index % 2 === 0 ? 'bg-gray-50/50' : ''}`}>
                      <td className="py-4 font-semibold text-gray-900">{phase.name}</td>
                      <td className="py-4 text-gray-600 text-sm">{phase.description}</td>
                      <td className="py-4 text-right font-semibold">{formatCurrency(phase.value)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="p-10 bg-gradient-to-r from-gray-50 to-gray-100 border-t-2 border-gray-200">
              <div className="w-80 ml-auto">
                <div className="space-y-3">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal (s/ IVA)</span>
                    <span className="font-medium">{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>IVA ({vatRate}%)</span>
                    <span className="font-medium">{formatCurrency(vatAmount)}</span>
                  </div>
                  <div className="h-px bg-gray-300 my-3" />
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-gray-900">Total</span>
                    <span className="text-3xl font-black text-primary">{formatCurrency(total)}</span>
                  </div>
                  <p className="text-xs text-gray-400 text-right">(IVA incluído à taxa legal)</p>
                </div>
              </div>
            </div>

            {/* Terms */}
            <div className="p-10 border-t border-gray-200">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">
                Condições Gerais
              </h2>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Pagamento de 30% na assinatura do contrato</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Pagamento de 40% na aprovação do Anteprojeto</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Pagamento de 30% na entrega do Projeto de Execução</span>
                  </p>
                </div>
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Prazo de execução conforme cronograma acordado</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Esta proposta é válida por 30 dias</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Valores sujeitos a revisão após validade</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-10 bg-gray-900 text-white">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-bold text-lg">Ferreira Arquitetos, Lda</p>
                  <p className="text-sm text-gray-400 mt-1">NIF: 123456789</p>
                  <p className="text-sm text-gray-400">geral@fa360.pt | +351 220 000 000</p>
                  <p className="text-sm text-gray-400">www.ferreiraarquitetos.pt</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-400">Documento gerado em</p>
                  <p className="font-medium">{formatDate(proposalDate)}</p>
                </div>
              </div>
            </div>

            {/* Signature Area */}
            <div className="p-10 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-12">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-12">Pelo Cliente</p>
                  <div className="border-b-2 border-gray-300 pb-4 mb-2 mx-8">
                    <p className="text-gray-400 text-sm">Assinatura</p>
                  </div>
                  <p className="font-medium text-gray-700">{clientData.name}</p>
                  <p className="text-xs text-gray-400 mt-2">Data: ___/___/_____</p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-12">Pelo Arquiteto</p>
                  <div className="border-b-2 border-gray-300 pb-4 mb-2 mx-8">
                    <p className="text-gray-400 text-sm">Assinatura e Carimbo</p>
                  </div>
                  <p className="font-medium text-gray-700">Ferreira Arquitetos</p>
                  <p className="text-xs text-gray-400 mt-2">Data: ___/___/_____</p>
                </div>
              </div>
            </div>

            {/* Disclaimer */}
            <div className="p-6 bg-gray-50 border-t border-gray-200">
              <p className="text-xs text-gray-400 text-center">
                Esta proposta foi gerada automaticamente pela plataforma FA-360. 
                Os valores apresentados são indicativos e podem ser ajustados após visita técnica.
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Email Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowEmailModal(false)} />
          <div className="relative bg-card p-6 rounded-xl shadow-xl w-full max-w-md">
            <h3 className="font-semibold mb-4">Enviar Proposta por Email</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Para: {clientData.email}
            </p>
            <textarea
              value={emailMessage}
              onChange={(e) => setEmailMessage(e.target.value)}
              placeholder="Mensagem opcional..."
              className="w-full h-32 px-4 py-3 bg-muted border border-border rounded-lg resize-none mb-4"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowEmailModal(false)}
                className="px-4 py-2 text-sm hover:bg-muted rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={sendEmail}
                className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                Abrir Email
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print Styles */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .fixed, .fixed * { visibility: visible; }
          .fixed { position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: white; overflow: visible; }
          .overflow-auto { overflow: visible !important; }
          button, .bg-card, .bg-muted { display: none !important; }
          .bg-muted\\/50 { background: white !important; padding: 0 !important; }
        }
      `}</style>
    </div>
  );
}
